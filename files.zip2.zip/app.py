"""
Svenska Coach — اپ یکپارچه‌ی تمرین سوئدی.
داشبورد امروز، بانک کلمات، خطاهای من، پیشرفت، و مربی هوش مصنوعی.
اجرا: streamlit run app.py
"""
import datetime
import html
import re

import pandas as pd
import plotly.express as px
import streamlit as st

import coach
import sheets_helper as sh
import srs
import vocab_extract

st.set_page_config(page_title="Svenska Coach", page_icon="🇸🇪", layout="wide")

# چرخه‌ی هفتگی تمرکز — دوشنبه=0 ... یکشنبه=6
WEEKDAY_FOCUS = {
    0: "مکالمه‌ی روزمره",
    1: "واژگان کاری / مصاحبه",
    2: "مکالمه‌ی روزمره",
    3: "واژگان کاری / مصاحبه",
    4: "مکالمه‌ی روزمره",
    5: "مرور هفته + سبک آزمون SFI/SAS",
    6: "آزاد، بدون تکلیف",
}


def parse_transcript_sentences(transcript_text):
    """
    خط‌های رونوشت («[0.0s -> 4.0s] متن») رو به لیستی از دیکشنری تبدیل می‌کنه:
    {"start": ثانیه یا None, "end": ثانیه یا None, "text": متن}
    """
    sentences = []
    pattern = re.compile(r"^\[(\d+\.?\d*)s\s*->\s*(\d+\.?\d*)s\]\s*(.*)$")
    for line in (transcript_text or "").splitlines():
        line = line.strip()
        if not line:
            continue
        m = pattern.match(line)
        if m:
            start, end, text = float(m.group(1)), float(m.group(2)), m.group(3).strip()
        else:
            start, end, text = None, None, line
        if text:
            sentences.append({"start": start, "end": end, "text": text})
    return sentences


def tokenize_words(sentence):
    """کلمات یه جمله رو جدا می‌کنه و علائم نگارشی اطرافشون رو حذف می‌کنه."""
    words = []
    for tok in sentence.split():
        cleaned = tok.strip(".,!?;:،؛\"'()[]«»")
        if cleaned:
            words.append(cleaned)
    return words

today_focus = WEEKDAY_FOCUS[datetime.date.today().weekday()]

st.title("🇸🇪 Svenska Coach")
st.caption(f"امروز: {datetime.date.today().strftime('%Y-%m-%d')} — تمرکز: {today_focus}")

tab_today, tab_vocab, tab_mistakes, tab_progress, tab_coach = st.tabs(
    ["📅 امروز", "📖 بانک کلمات", "⚠️ خطاهای من", "📈 پیشرفت", "🤖 مربی"]
)

# ---------------- تب امروز ----------------
with tab_today:
    st.subheader(f"تمرکز امروز: {today_focus}")

    # قابلیت دانلود/رونویسی فقط رو نسخه‌ی محلی در دسترسه (به کتابخونه‌های سنگین نیاز داره)
    can_fetch = True
    try:
        import config
        from fetch_podcast import fetch_new_podcast_episodes, load_state, save_state
        from fetch_youtube import fetch_new_youtube_audio
        from transcribe import transcribe_file
    except ImportError:
        can_fetch = False

    if can_fetch:
        if st.button("📥 دریافت محتوای جدید"):
            with st.spinner("در حال دانلود و رونویسی... ممکنه چند دقیقه طول بکشه"):
                state = load_state(config.STATE_FILE)
                new_files = []
                for name, url in config.PODCAST_FEEDS.items():
                    new_files += fetch_new_podcast_episodes(
                        name, url, config.DOWNLOAD_DIR, state, config.MAX_EPISODES_PER_RUN
                    )
                for name, url in config.YOUTUBE_SOURCES.items():
                    new_files += fetch_new_youtube_audio(
                        name, url, config.DOWNLOAD_DIR, state, config.MAX_EPISODES_PER_RUN
                    )
                save_state(config.STATE_FILE, state)

                for path in new_files:
                    txt_path = transcribe_file(path, model_size=config.WHISPER_MODEL_SIZE)
                    with open(txt_path, "r", encoding="utf-8") as f:
                        transcript = f.read()
                    title = path.replace("\\", "/").split("/")[-1]
                    sh.append_row(
                        "audio_log",
                        [str(datetime.date.today()), "local", title, path, transcript[:45000]],
                    )
            st.success(f"{len(new_files)} فایل جدید دریافت و رونویسی شد.")
            st.rerun()
    else:
        st.info(
            "قابلیت دانلود خودکار فقط رو نسخه‌ی محلی (کامپیوتر) در دسترسه. "
            "اینجا (نسخه‌ی ابری) فقط رونوشت‌های قبلی رو می‌بینی و می‌تونی با مربی تمرین کنی."
        )

    st.divider()
    st.subheader("جلسه‌های اخیر")
    audio_df = sh.read_tab("audio_log")
    if audio_df.empty:
        st.write("هنوز جلسه‌ای ثبت نشده.")
    else:
        for _, row in audio_df.tail(5).iloc[::-1].iterrows():
            entry_key = f"{row.get('تاریخ','')}_{row.get('عنوان','')}"
            transcript_text = row.get("رونوشت", "")
            with st.expander(f"{row.get('تاریخ', '')} — {row.get('عنوان', '')}"):
                if can_fetch:
                    try:
                        st.audio(row["مسیر_محلی"])
                    except Exception:
                        st.caption("فایل صوتی رو این دستگاه در دسترس نیست.")

                sentences = parse_transcript_sentences(transcript_text)

                # کلمات یکتا + اطلاعات (متن/زمان) جمله‌ای که اولین‌بار توش اومدن
                word_to_info = {}
                unique_words = []
                for sentence in sentences:
                    for w in tokenize_words(sentence["text"]):
                        if w not in word_to_info:
                            word_to_info[w] = sentence
                            unique_words.append(w)

                # معنی‌های کوتاه برای تولتیپ هاور — فقط یه‌بار در کل عمر جلسه محاسبه می‌شه
                meanings_key = f"hover_meanings_{entry_key}"
                if meanings_key not in st.session_state:
                    if unique_words:
                        with st.spinner("در حال آماده‌سازی تولتیپ کلمات..."):
                            st.session_state[meanings_key] = vocab_extract.batch_lookup_meanings(
                                unique_words, transcript_text
                            )
                    else:
                        st.session_state[meanings_key] = {}
                hover_meanings = st.session_state[meanings_key]

                st.caption("موس رو هر کلمه نگه دار تا معنیش رو ببینی. برای اضافه‌کردن به بانک کلمات، از لیست پایین انتخابش کن.")

                # ---------- نمایش HTML با تولتیپ هاور (native title) ----------
                html_parts = ['<div style="line-height:2.4; font-size:16px;">']
                for sentence in sentences:
                    html_parts.append('<p dir="ltr" style="text-align:left; margin:4px 0;">')
                    for w in tokenize_words(sentence["text"]):
                        meaning = html.escape(str(hover_meanings.get(w, "")))
                        word_html = html.escape(w)
                        html_parts.append(
                            f'<span title="{meaning}" '
                            f'style="border-bottom:1px dotted #888; cursor:help; margin-left:3px;">'
                            f'{word_html}</span>'
                        )
                    html_parts.append("</p>")
                html_parts.append("</div>")
                st.markdown("".join(html_parts), unsafe_allow_html=True)

                # ---------- انتخاب کلمه برای افزودن به بانک + کارت آنکی ----------
                if unique_words:
                    st.pills(
                        "کلماتی که نمی‌دونستی رو انتخاب کن:",
                        options=unique_words,
                        selection_mode="multi",
                        key=f"pills_{entry_key}",
                    )

                    if st.button("➕ افزودن کلمات انتخاب‌شده به بانک کلمات", key=f"add_{entry_key}"):
                        selected = st.session_state.get(f"pills_{entry_key}", [])
                        if not selected:
                            st.info("هیچ کلمه‌ای انتخاب نشده بود.")
                        else:
                            pairs = [(w, word_to_info[w]["text"]) for w in selected]
                            with st.spinner("در حال گرفتن جزئیات از مربی..."):
                                details = vocab_extract.batch_lookup_details(pairs)

                            apkg_items = []
                            added = 0
                            for d in details:
                                word = d.get("word", "")
                                info = word_to_info.get(word, {})
                                meaning_line = f"{d.get('meaning', '')} ({d.get('pos', '')})".strip()
                                extra_lines = [info.get("text", "")]
                                if d.get("forms"):
                                    extra_lines.append(f"صرف: {d['forms']}")
                                for ex in d.get("examples", []):
                                    extra_lines.append(f"مثال: {ex.get('sv','')} — {ex.get('fa','')}")
                                jomle_field = "\n".join(line for line in extra_lines if line)

                                sh.append_row(
                                    "ordbank",
                                    [str(datetime.date.today()), word, meaning_line, jomle_field, 0, ""],
                                )
                                added += 1
                                with st.expander(f"✅ {word} — {meaning_line}"):
                                    for ex in d.get("examples", []):
                                        st.write(f"🔹 {ex.get('sv','')} — {ex.get('fa','')}")

                                apkg_items.append({
                                    "word": word,
                                    "sentence": info.get("text", ""),
                                    "meaning": d.get("meaning", ""),
                                    "pos": d.get("pos", ""),
                                    "forms": d.get("forms", ""),
                                    "examples": d.get("examples", []),
                                    "audio_source_path": row["مسیر_محلی"] if can_fetch else None,
                                    "start": info.get("start"),
                                    "end": info.get("end"),
                                })

                            if added:
                                st.success(f"{added} کلمه به بانک کلمات اضافه شد.")

                            # ---------- ساخت کارت آنکی (فقط نسخه‌ی محلی) ----------
                            if can_fetch and apkg_items:
                                try:
                                    import anki_export
                                    apkg_path = f"anki_export_{entry_key}.apkg".replace(" ", "_")
                                    with st.spinner("در حال ساخت کارت‌های آنکی..."):
                                        anki_export.build_apkg(apkg_items, "Ordförråd", apkg_path)
                                    with open(apkg_path, "rb") as f:
                                        st.download_button(
                                            "📥 دانلود دسته‌ی آنکی (.apkg)",
                                            data=f.read(),
                                            file_name="svenska_coach.apkg",
                                            mime="application/octet-stream",
                                            key=f"apkg_{entry_key}",
                                        )
                                except ImportError:
                                    st.caption("برای ساخت کارت آنکی، کتابخونه‌ی genanki رو نصب کن: pip install genanki")

# ---------------- تب بانک کلمات ----------------
with tab_vocab:
    st.subheader("📖 بانک کلمات")
    vocab_df = sh.read_tab("ordbank")

    # ---------- بخش مرور فلش‌کارتی (SRS) ----------
    st.markdown("### 🎴 مرور امروز")

    if "srs_queue" not in st.session_state:
        st.session_state.srs_queue = None
        st.session_state.srs_index = 0
        st.session_state.srs_show_answer = False
        st.session_state.srs_correct_count = 0

    due_df = srs.get_due_words(vocab_df)

    if st.session_state.srs_queue is None:
        if due_df.empty:
            st.info("امروز کلمه‌ای برای مرور نداری. 🎉")
        else:
            st.write(f"امروز **{len(due_df)}** کلمه برای مرور آماده‌ست.")
            if st.button("▶️ شروع مرور"):
                st.session_state.srs_queue = due_df.to_dict("records")
                st.session_state.srs_index = 0
                st.session_state.srs_show_answer = False
                st.session_state.srs_correct_count = 0
                st.rerun()

    else:
        queue = st.session_state.srs_queue
        idx = st.session_state.srs_index

        if idx >= len(queue):
            st.success(
                f"امروز {len(queue)} کلمه مرور شد، {st.session_state.srs_correct_count} تا درست. 👏"
            )
            if st.button("🔁 بستن جلسه‌ی مرور"):
                st.session_state.srs_queue = None
                st.rerun()
        else:
            card = queue[idx]
            st.caption(f"کارت {idx + 1} از {len(queue)}")
            st.markdown(f"## {card.get('کلمه', '')}")

            if not st.session_state.srs_show_answer:
                if st.button("🔍 نشون بده"):
                    st.session_state.srs_show_answer = True
                    st.rerun()
            else:
                st.write(f"**معنی:** {card.get('معنی', '')}")
                if card.get("جمله"):
                    st.write(f"**جمله:** {card.get('جمله', '')}")

                col_yes, col_no = st.columns(2)

                def _go_next(correct):
                    new_level, next_date = srs.compute_next_review(card.get("سطح", 0), correct)
                    sh.update_cells_by_match(
                        "ordbank", "کلمه", card.get("کلمه", ""),
                        {"سطح": new_level, "مرور_بعدی": next_date},
                    )
                    if correct:
                        st.session_state.srs_correct_count += 1
                    st.session_state.srs_index += 1
                    st.session_state.srs_show_answer = False

                if col_yes.button("✅ بلد بودم"):
                    _go_next(True)
                    st.rerun()
                if col_no.button("❌ بلد نبودم"):
                    _go_next(False)
                    st.rerun()

    st.divider()
    st.markdown("### فهرست کامل و ویرایش دستی")
    edited_vocab = st.data_editor(
        vocab_df, num_rows="dynamic", use_container_width=True, key="vocab_editor"
    )
    if st.button("💾 ذخیره‌ی تغییرات بانک کلمات"):
        sh.overwrite_tab("ordbank", edited_vocab)
        st.success("ذخیره شد.")
        st.rerun()

# ---------------- تب خطاهای من ----------------
with tab_mistakes:
    st.subheader("⚠️ خطاهای تکراری من")
    st.caption("مهم‌ترین جدول — مربی تمرین گرامری رو بر همین اساس طراحی می‌کنه.")
    mistakes_df = sh.read_tab("mina_fel")
    edited_mistakes = st.data_editor(
        mistakes_df, num_rows="dynamic", use_container_width=True, key="mistakes_editor"
    )
    if st.button("💾 ذخیره‌ی تغییرات خطاها"):
        sh.overwrite_tab("mina_fel", edited_mistakes)
        st.success("ذخیره شد.")
        st.rerun()

# ---------------- تب پیشرفت ----------------
with tab_progress:
    st.subheader("📈 پیشرفت")
    progress_df = sh.read_tab("progress")

    with st.form("log_progress_form"):
        col1, col2 = st.columns(2)
        topic = col1.text_input("موضوع جلسه", value=today_focus)
        pct = col2.slider("درصد فهم صوت بدون متن", 0, 100, 50)
        note = st.text_input("نکته (اختیاری)")
        if st.form_submit_button("➕ ثبت جلسه‌ی امروز"):
            sh.append_row("progress", [str(datetime.date.today()), topic, pct, note])
            st.success("ثبت شد.")
            st.rerun()

    if not progress_df.empty:
        progress_df["درصد_فهم"] = pd.to_numeric(progress_df["درصد_فهم"], errors="coerce")
        fig = px.line(
            progress_df, x="تاریخ", y="درصد_فهم", markers=True, title="روند درصد فهم شنیداری"
        )
        st.plotly_chart(fig, use_container_width=True)
        st.dataframe(progress_df, use_container_width=True)
    else:
        st.write("هنوز جلسه‌ای ثبت نشده.")

# ---------------- تب مربی ----------------
with tab_coach:
    st.subheader("🤖 مربی هوش مصنوعی")

    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    vocab_df = sh.read_tab("ordbank")
    mistakes_df = sh.read_tab("mina_fel")
    system_prompt = coach.build_system_prompt(today_focus, vocab_df, mistakes_df)

    for msg in st.session_state.chat_history:
        with st.chat_message(msg["role"]):
            st.write(msg["content"])

    user_input = st.chat_input("پیام بده... (فارسی یا سوئدی)")
    if user_input:
        st.session_state.chat_history.append({"role": "user", "content": user_input})
        with st.chat_message("user"):
            st.write(user_input)

        with st.chat_message("assistant"):
            with st.spinner("..."):
                reply = coach.ask_coach(st.session_state.chat_history, system_prompt)
                st.write(reply)
        st.session_state.chat_history.append({"role": "assistant", "content": reply})
