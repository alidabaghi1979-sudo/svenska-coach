"""
Svenska Coach — اپ یکپارچه‌ی تمرین سوئدی.
داشبورد امروز، بانک کلمات، خطاهای من، پیشرفت، و مربی هوش مصنوعی.
اجرا: streamlit run app.py
"""
import datetime

import pandas as pd
import plotly.express as px
import streamlit as st

import coach
import sheets_helper as sh
import srs

st.set_page_config(page_title="Svenska Coach", page_icon="🇸🇪", layout="wide")

# چرخه‌ی هفتگی تمرکز — دوشنبه=0 ... یکشنبه=6
WEEKDAY_FOCUS = {
    0: "مکالمه‌ی روزمره",
    1: "واژگان کاری / مصاحبه",
    2: "مکالمه‌ی روزمره",
    3: "واژگان کاری / مصاحبه",
    4: "مکالمه‌ی روزمره",
    5: "مرور هفته + سبک آزمون SFI/SAS",
    6: "آزاد، بدون تکلیف",
}

today_focus = WEEKDAY_FOCUS[datetime.date.today().weekday()]

st.title("🇸🇪 Svenska Coach")
st.caption(f"امروز: {datetime.date.today().strftime('%Y-%m-%d')} — تمرکز: {today_focus}")

tab_today, tab_vocab, tab_mistakes, tab_progress, tab_coach = st.tabs(
    ["📅 امروز", "📖 بانک کلمات", "⚠️ خطاهای من", "📈 پیشرفت", "🤖 مربی"]
)

# ---------------- تب امروز ----------------
with tab_today:
    st.subheader(f"تمرکز امروز: {today_focus}")

    # قابلیت دانلود/رونویسی فقط رو نسخه‌ی محلی در دسترسه (به کتابخونه‌های سنگین نیاز داره)
    can_fetch = True
    try:
        import config
        from fetch_podcast import fetch_new_podcast_episodes, load_state, save_state
        from fetch_youtube import fetch_new_youtube_audio
        from transcribe import transcribe_file
    except ImportError:
        can_fetch = False

    if can_fetch:
        if st.button("📥 دریافت محتوای جدید"):
            with st.spinner("در حال دانلود و رونویسی... ممکنه چند دقیقه طول بکشه"):
                state = load_state(config.STATE_FILE)
                new_files = []
                for name, url in config.PODCAST_FEEDS.items():
                    new_files += fetch_new_podcast_episodes(
                        name, url, config.DOWNLOAD_DIR, state, config.MAX_EPISODES_PER_RUN
                    )
                for name, url in config.YOUTUBE_SOURCES.items():
                    new_files += fetch_new_youtube_audio(
                        name, url, config.DOWNLOAD_DIR, state, config.MAX_EPISODES_PER_RUN
                    )
                save_state(config.STATE_FILE, state)

                for path in new_files:
                    txt_path = transcribe_file(path, model_size=config.WHISPER_MODEL_SIZE)
                    with open(txt_path, "r", encoding="utf-8") as f:
                        transcript = f.read()
                    title = path.replace("\\", "/").split("/")[-1]
                    sh.append_row(
                        "audio_log",
                        [str(datetime.date.today()), "local", title, path, transcript[:45000]],
                    )
            st.success(f"{len(new_files)} فایل جدید دریافت و رونویسی شد.")
            st.rerun()
    else:
        st.info(
            "قابلیت دانلود خودکار فقط رو نسخه‌ی محلی (کامپیوتر) در دسترسه. "
            "اینجا (نسخه‌ی ابری) فقط رونوشت‌های قبلی رو می‌بینی و می‌تونی با مربی تمرین کنی."
        )

    st.divider()
    st.subheader("جلسه‌های اخیر")
    audio_df = sh.read_tab("audio_log")
    if audio_df.empty:
        st.write("هنوز جلسه‌ای ثبت نشده.")
    else:
        for _, row in audio_df.tail(5).iloc[::-1].iterrows():
            with st.expander(f"{row.get('تاریخ', '')} — {row.get('عنوان', '')}"):
                if can_fetch:
                    try:
                        st.audio(row["مسیر_محلی"])
                    except Exception:
                        st.caption("فایل صوتی رو این دستگاه در دسترس نیست.")
                st.text(row.get("رونوشت", ""))

# ---------------- تب بانک کلمات ----------------
with tab_vocab:
    st.subheader("📖 بانک کلمات")
    vocab_df = sh.read_tab("ordbank")

    # ---------- بخش مرور فلش‌کارتی (SRS) ----------
    st.markdown("### 🎴 مرور امروز")

    if "srs_queue" not in st.session_state:
        st.session_state.srs_queue = None
        st.session_state.srs_index = 0
        st.session_state.srs_show_answer = False
        st.session_state.srs_correct_count = 0

    due_df = srs.get_due_words(vocab_df)

    if st.session_state.srs_queue is None:
        if due_df.empty:
            st.info("امروز کلمه‌ای برای مرور نداری. 🎉")
        else:
            st.write(f"امروز **{len(due_df)}** کلمه برای مرور آماده‌ست.")
            if st.button("▶️ شروع مرور"):
                st.session_state.srs_queue = due_df.to_dict("records")
                st.session_state.srs_index = 0
                st.session_state.srs_show_answer = False
                st.session_state.srs_correct_count = 0
                st.rerun()

    else:
        queue = st.session_state.srs_queue
        idx = st.session_state.srs_index

        if idx >= len(queue):
            st.success(
                f"امروز {len(queue)} کلمه مرور شد، {st.session_state.srs_correct_count} تا درست. 👏"
            )
            if st.button("🔁 بستن جلسه‌ی مرور"):
                st.session_state.srs_queue = None
                st.rerun()
        else:
            card = queue[idx]
            st.caption(f"کارت {idx + 1} از {len(queue)}")
            st.markdown(f"## {card.get('کلمه', '')}")

            if not st.session_state.srs_show_answer:
                if st.button("🔍 نشون بده"):
                    st.session_state.srs_show_answer = True
                    st.rerun()
            else:
                st.write(f"**معنی:** {card.get('معنی', '')}")
                if card.get("جمله"):
                    st.write(f"**جمله:** {card.get('جمله', '')}")

                col_yes, col_no = st.columns(2)

                def _go_next(correct):
                    new_level, next_date = srs.compute_next_review(card.get("سطح", 0), correct)
                    sh.update_cells_by_match(
                        "ordbank", "کلمه", card.get("کلمه", ""),
                        {"سطح": new_level, "مرور_بعدی": next_date},
                    )
                    if correct:
                        st.session_state.srs_correct_count += 1
                    st.session_state.srs_index += 1
                    st.session_state.srs_show_answer = False

                if col_yes.button("✅ بلد بودم"):
                    _go_next(True)
                    st.rerun()
                if col_no.button("❌ بلد نبودم"):
                    _go_next(False)
                    st.rerun()

    st.divider()
    st.markdown("### فهرست کامل و ویرایش دستی")
    edited_vocab = st.data_editor(
        vocab_df, num_rows="dynamic", use_container_width=True, key="vocab_editor"
    )
    if st.button("💾 ذخیره‌ی تغییرات بانک کلمات"):
        sh.overwrite_tab("ordbank", edited_vocab)
        st.success("ذخیره شد.")
        st.rerun()

# ---------------- تب خطاهای من ----------------
with tab_mistakes:
    st.subheader("⚠️ خطاهای تکراری من")
    st.caption("مهم‌ترین جدول — مربی تمرین گرامری رو بر همین اساس طراحی می‌کنه.")
    mistakes_df = sh.read_tab("mina_fel")
    edited_mistakes = st.data_editor(
        mistakes_df, num_rows="dynamic", use_container_width=True, key="mistakes_editor"
    )
    if st.button("💾 ذخیره‌ی تغییرات خطاها"):
        sh.overwrite_tab("mina_fel", edited_mistakes)
        st.success("ذخیره شد.")
        st.rerun()

# ---------------- تب پیشرفت ----------------
with tab_progress:
    st.subheader("📈 پیشرفت")
    progress_df = sh.read_tab("progress")

    with st.form("log_progress_form"):
        col1, col2 = st.columns(2)
        topic = col1.text_input("موضوع جلسه", value=today_focus)
        pct = col2.slider("درصد فهم صوت بدون متن", 0, 100, 50)
        note = st.text_input("نکته (اختیاری)")
        if st.form_submit_button("➕ ثبت جلسه‌ی امروز"):
            sh.append_row("progress", [str(datetime.date.today()), topic, pct, note])
            st.success("ثبت شد.")
            st.rerun()

    if not progress_df.empty:
        progress_df["درصد_فهم"] = pd.to_numeric(progress_df["درصد_فهم"], errors="coerce")
        fig = px.line(
            progress_df, x="تاریخ", y="درصد_فهم", markers=True, title="روند درصد فهم شنیداری"
        )
        st.plotly_chart(fig, use_container_width=True)
        st.dataframe(progress_df, use_container_width=True)
    else:
        st.write("هنوز جلسه‌ای ثبت نشده.")

# ---------------- تب مربی ----------------
with tab_coach:
    st.subheader("🤖 مربی هوش مصنوعی")

    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    vocab_df = sh.read_tab("ordbank")
    mistakes_df = sh.read_tab("mina_fel")
    system_prompt = coach.build_system_prompt(today_focus, vocab_df, mistakes_df)

    for msg in st.session_state.chat_history:
        with st.chat_message(msg["role"]):
            st.write(msg["content"])

    user_input = st.chat_input("پیام بده... (فارسی یا سوئدی)")
    if user_input:
        st.session_state.chat_history.append({"role": "user", "content": user_input})
        with st.chat_message("user"):
            st.write(user_input)

        with st.chat_message("assistant"):
            with st.spinner("..."):
                reply = coach.ask_coach(st.session_state.chat_history, system_prompt)
                st.write(reply)
        st.session_state.chat_history.append({"role": "assistant", "content": reply})
